for f in test1/Let*.jack;
do
    bash test.sh $f
done