for f in test1/If*.jack;
do
    bash test.sh $f
done