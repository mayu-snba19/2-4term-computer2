for f in test1/Hello/*.jack;
do
    bash test.sh $f
done