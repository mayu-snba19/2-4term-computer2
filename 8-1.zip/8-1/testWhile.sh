for f in test1/While*.jack;
do
    bash test.sh $f
done