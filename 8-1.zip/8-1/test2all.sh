for f in test2/*/*.jack;
do
    bash test.sh $f
done